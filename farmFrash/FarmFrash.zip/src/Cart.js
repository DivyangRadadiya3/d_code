import React from "react";
import { useSelector, useDispatch } from 'react-redux';
import { incNumber, decNumber, removeItem } from './Action/index';

const Mycart = () => {
    const myState = useSelector((state) => state.UpdationProvider.items);
    const dispatch = useDispatch();
    let total = 0;

    return (
        <>
            <div className="cart-items">
                {
                    myState.map((item, index) => {
                        total += item.price * item.qty;
                        return <div className='product-card' key={index}>
                            <img src={item.imgsrc} alt={item.head} className='card_img' />
                            <div className='product-info'>
                                <span className='product-title'>{item.head}</span><br />
                                <span className='product-price'>₹{item.price} /KG</span>
                            </div>
                            <div className="product-totalprice">
                                Total: ₹{item.price * item.qty}
                            </div>
                            <div className="cart-btn">
                                <button className="remove" onClick={() => dispatch(removeItem(item))} >Remove</button>
                                <div className="product-qty">
                                    <button title="Decrement" onClick={() => dispatch(decNumber(item))}>-</button>
                                    <span> {item.qty} </span>
                                    <button title="Increment" onClick={() => dispatch(incNumber(item))}>+</button>
                                </div>
                            </div>
                        </div>
                    })
                }
            </div>
            <div className="footer">
                Total Bill Amount:{total}
            </div>
        </>
    )
};

export default Mycart;