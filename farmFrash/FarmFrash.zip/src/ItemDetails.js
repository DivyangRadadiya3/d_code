export const data = [
    {
        id:0,
        imgsrc:'../sweet potato.jpeg',
        head:'Sweet Potato',
        price:'150',
        qty:1
    },
    {
        id:1,
        imgsrc:'../tomato.jpeg',
        head:'Tomato',
        price:'130',
        qty:1
    },
    {
        id:2,
        imgsrc:'../potato.jpg',
        head:'Potato',
        price:'140',
        qty:1
    },
    {
        id:3,
        imgsrc:'../carrot.jpeg',
        head:'Carrot',
        price:'150',
        qty:1
    },
    {
        id:4,
        imgsrc:'../brinjal.jpeg',
        head:'Brinjal',
        price:'150',
        qty:1
    },
    {
        id:5,
        imgsrc:'../red chili.jpeg',
        head:'Red Chilli',
        price:'140',
        qty:1
    },
    {
        id:6,
        imgsrc:'../green chili.jpeg',
        head:'Green Chilli',
        price:'110',
        qty:1
    },
    {
        id:7,
        imgsrc:'../peas.jpeg',
        head:'Green Peas',
        price:'112',
        qty:1
    },
    {
        id:8,
        imgsrc:'../cabbage.jpeg',
        head:'Cabbage',
        price:'150',
        qty:1
    },
    {
        id:9,
        imgsrc:'../cauliflower.jpeg',
        head:'Cauliflower',
        price:'130',
        qty:1
    },
    {
        id:10,
        imgsrc:'../onion.jpeg',
        head:'Onion',
        price:'150',
        qty:1
    },
    {
        id:11,
        imgsrc:'../green onion.jpeg',
        head:'Green Onion',
        price:'140',
        qty:1
    },
    {
        id:12,
        imgsrc:'../cucumber.jpeg',
        head:'Cucumber',
        price:'145',
        qty:1
    },
    {
        id:13,
        imgsrc:'../ladyfinger.jpeg',
        head:'Ladyfinger',
        price:'105',
        qty:1
    },
    {
        id:14,
        imgsrc:'../broccoli.jpeg',
        head:'Broccoli',
        price:'145',
        qty:1
    }
]