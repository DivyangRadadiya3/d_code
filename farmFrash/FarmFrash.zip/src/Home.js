import React from "react";
import { useDispatch } from 'react-redux';
import { data } from "./ItemDetails";
import { addItem } from "./Action/index";

function HomePage() {
    const dispatch = useDispatch();

    return (
        <>
            <div className='product-container'>
                {
                    data.map((item) => {
                        return <div className='product-card' key={item.id}>
                            <img src={item.imgsrc} alt={item.head} className='card_img' />
                            <div className="bottom-left">
                                <div className='product-info'>
                                    <span className='product-title'>{item.head}</span><br />
                                    <p className='product-price'>₹{item.price} /KG</p>
                                    <div className="btn">
                                        <button className="addCart-btn" title="ADD_ITEM" onClick={() => dispatch(addItem(item))}>Add Cart</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    })
                }
            </div>
        </>
    )
};

export default HomePage;