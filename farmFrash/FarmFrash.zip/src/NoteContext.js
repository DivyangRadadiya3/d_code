import { createContext } from "react";

const NoteContext = createContext({ list: null, setList: null});

export default NoteContext;