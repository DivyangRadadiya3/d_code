import { combineReducers } from 'redux';
import UpdationProvider from  './UpdationProvider';

const rootReducer = combineReducers({
    UpdationProvider
});

export default rootReducer;