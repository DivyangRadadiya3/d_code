const initialData = {
    items: []
}

const UpdationProvider = (state = initialData, action) => {
    switch (action.type) {
        case "ADD_ITEM":
            const index = state.items.findIndex(item => item.id === action.item.id);
            if (index !== -1) {
                return {
                    ...state,
                    items: state.items.map(item => item.id === action.item.id
                        ? {
                            ...item,
                            qty: item.qty + 1,
                        }
                        : item
                    )
                }
            } else {
                return {
                    ...state,
                    items: [...state.items, action.item]
                }
            }

        case "REMOVE_ITEM":
            return {
                ...state,
                items: state.items.filter(elem => elem.id !== action.item.id)
            }

        case "INCREMENT":
            const findItem = state.items.filter(item => item.id === action.item.id)[0];
            return {
                ...state,
                items: state.items.map(item =>
                    item.id === action.item.id
                        ? {
                            ...findItem,
                            qty: findItem.qty + 1
                        }
                        : item
                )
            }

        case "DECREMENT":
            const findProduct = state.items.filter(item => item.id === action.item.id)[0];
            if (findProduct.qty > 1) {
                return {
                    ...state,
                    items: state.items.map(item =>
                        item.id === action.item.id
                            ? {
                                ...findProduct,
                                qty: findProduct.qty - 1
                            }
                            : item
                    )
                }
            }
            else {
                return {
                    ...state
                }
            }

        default: return state;
    }
}

export default UpdationProvider;