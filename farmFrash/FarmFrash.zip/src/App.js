import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Menu from './Menu.js';
import Home from './Home';
import Cart from './Cart';
import './Food.css';

function App() {
  return (
    <>
      <div className="header">
        <Menu />
      </div>
      <Routes>
        <Route exact path='/' element={<Home name='Home' />} />
        <Route path='/cart' element={<Cart name='Cart' />} />
        <Route path='*' element={<Home name='Home' />} />
      </Routes>
    </>
  );
}

export default App;