import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';

const Menu = () => {
    const myState = useSelector((state) => state.UpdationProvider.items);
    const arrLength = myState.filter((elem, index) => myState.indexOf(elem) === index);

    return (
        <>
            <div className="logo">
                <span>FreshFarm</span>
            </div>
            <nav className="nav-bar">
                <Link to="/cart" className='cart'>
                    CART
                    <span className="cartLength">{arrLength.length}</span>
                </Link>
                <Link to="/">HOME</Link>
            </nav>
        </>
    );
};

export default Menu;